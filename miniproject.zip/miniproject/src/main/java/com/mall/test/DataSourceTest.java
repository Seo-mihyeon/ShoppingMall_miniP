package com.mall.test;

import org.junit.runner.RunWith;

public class DataSourceTest {

}
